<?php
/**
 * phpGrid Module Entry Point
 * 
 * @package    
 * @subpackage 
 * @link phpgrid.com
 * @license        GPL
 * Show phpGrid in joomla module
 */
 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
//jimport( 'joomla.html.pagination' );
// Include the syndicate functions only once
//require_once( dirname(__FILE__).DS.'helper.php' );
 
require( JModuleHelper::getLayoutPath( 'mod_phpgrid' ) );

?>