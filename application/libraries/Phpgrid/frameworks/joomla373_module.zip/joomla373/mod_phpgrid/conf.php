<?php
// mysql example
define('PHPGRID_DB_HOSTNAME','localhost'); // database host name
define('PHPGRID_DB_USERNAME', 'root');     // database user name
define('PHPGRID_DB_PASSWORD', ''); // database password
define('PHPGRID_DB_NAME', 'sampledb'); // database name
define('PHPGRID_DB_TYPE', 'mysql');  // database type
define('PHPGRID_DB_CHARSET','utf8'); // ex: utf8(for mysql),AL32UTF8 (for oracle), leave blank to use the default charset



define('SERVER_ROOT', '/joomla373/modules/mod_phpgrid');
define('THEME', 'lux');
define('FRAMEWORK', '');	// indicating framework integrating - not used yet
define('DEBUG', false); // *** MUST SET TO FALSE WHEN DEPLOYED IN PRODUCTION ***
define('CDN', false);        // use Cloud CDN by default. False to use the local libraries
define('UPLOADEXT', 'gif,png,jpg,jpeg');


/******** DO NOT MODIFY ***********/
require_once('phpGrid.php');
/**********************************/
?>
