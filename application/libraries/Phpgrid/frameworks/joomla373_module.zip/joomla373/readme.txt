Download and extract phpGrid into 'mod_phpgrid" folder. Please follow the notes in setup-notes folder and use installation reference: https://www.ostraining.com/blog/joomla/custom-module-backend/

Note that it is not required to setup the FRAMEWORK value in conf.php 

The current module lack UI and uses the template file default.php to directly output a hard-coded grid. It is not the best practice but to only demostrate how phpGrid can be used as a Joomla module. We can improve the module implementation by moving the phpGrid code into the mod_phpgrid.php file. Additionally we can add a form field in the module that can take SQL as a parameter so that the you can insert datagrid dynamically on a Joomla page. 

Team phpGrid 2017